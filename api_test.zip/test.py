import asyncio
from playwright.async_api import async_playwright

async def test_search_engine():
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False)
        context = await browser.new_context(ignore_https_errors=True)
        page = await context.new_page()

        page.on("console", lambda msg: print(f"Console: {msg.text}"))
        page.on("requestfailed", lambda req: print(f"Failed: {req.url} -> {req.failure.error_text}"))

        try:
            await page.goto("https://duckduckgo.com", wait_until="networkidle")
            await page.wait_for_timeout(3600000)  # 1 hour = 3600000 ms

            print("✅ Loaded DuckDuckGo")
        except Exception as e:
            print(f"❌ Failed to load DuckDuckGo: {e}")

        await browser.close()

asyncio.run(test_search_engine())
