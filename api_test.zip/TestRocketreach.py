import requests
from bs4 import BeautifulSoup
import time
import random
import jwt
import asyncio
from playwright.async_api import Page
import chrome_playwrite_proxy  # Your custom Playwright launcher
import re

# === GLOBAL CONFIG ===
API_BASE = "http://localhost:5073"
LOGIN_URL = f"{API_BASE}/api/login"
NEXT_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next"
UPDATE_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next/insertorupdate"
MARK_NOT_FOUND_URL = f"{API_BASE}/api/DomainNames/filter"
GET_PROXY_URL = f"{API_BASE}/api/Proxies/next?is_used=0"
UPDATE_PROXY_URL = f"{API_BASE}/api/Proxies"

session = requests.Session()
access_token = None
refresh_token = None
proxy = None  # Global proxy instance
page, context, browser = None, None, None  # global browser context
TIMEOUT_THRESHOLD = 3
counters = {
    "timeout_failures": 0,
    "processed_count": 0
}


# === CAPTCHA HANDLER ===
def is_captcha_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    if "Unfortunately, bots use DuckDuckGo too" in soup.text:
        print("🛑 CAPTCHA detected on DuckDuckGo!")
        return True
    return False

# === DOMAIN EXISTENCE CHECK ===
def check_domain_exists(domain):
    try:
        response = requests.head(f"http://{domain}", timeout=5)
        return response.status_code < 400
    except:
        return False
    
# === AUTH ===
def login():
    global access_token, refresh_token
    response = requests.post(LOGIN_URL, json={"username": "keshav", "password": "keshav"})
    if response.status_code == 200:
        data = response.json()
        access_token = data['accessToken']
        refresh_token = data['refreshToken']
        session.headers.update({"Authorization": f"Bearer {access_token}"})
    else:
        print("❌ Login failed")
        exit(1)

def is_token_expired():
    try:
        decoded = jwt.decode(access_token, options={"verify_signature": False})
        exp_time = decoded.get("exp")
        return not exp_time or time.time() > exp_time - 60
    except:
        return True

def ensure_token_valid():
    if is_token_expired():
        login()

def get_traffic_left(proxy):
    try:
        url = f"https://{proxy['user']}:{proxy['pass']}@{proxy['api_url']}/api/stats"
        headers = {"Authorization": f"Bearer {proxy['api_key']}"}
        res = requests.get(url, headers=headers, timeout=10)
        return res.json().get("traffic_left", 0)
    except Exception as e:
        print("❌ Failed to check bandwidth:", e)
        return 0

def rotate_ip(proxy):
    traffic = get_traffic_left(proxy)
    if traffic < 1 * 1024 * 1024:
        print("🚫 Not enough bandwidth left.")
        return False
    try:
        url = f"https://{proxy['user']}:{proxy['pass']}@{proxy['api_url']}/api/rotate_ip"
        headers = {"Authorization": f"Bearer {proxy['api_key']}"}
        res = requests.get(url, headers=headers, params={"port": proxy["port"]}, timeout=10)
        print("🔁 IP rotated successfully.")
        return res.ok
    except Exception as e:
        print("❌ Failed to rotate IP:", e)
        return False
# === DATA FETCH/UPDATE ===
def get_next_domain():
    ensure_token_valid()
    response = session.get(NEXT_DOMAIN_URL)
    if response.status_code == 200:
        data = response.json()
        return data.get("data")
    return None

def update_domain(domain_name, email_patterns, company_details):
    ensure_token_valid()
    payload = {
        "filter": {"domain_name": domain_name},
        "update": {
            "processed": 2,
            "email_format": email_patterns,
            "details": company_details
        }
    }
    session.put(UPDATE_DOMAIN_URL, json=payload)

def mark_domain_not_found(domain_name):
    ensure_token_valid()
    session.put(MARK_NOT_FOUND_URL, json={"filter": {"domain_name": domain_name}, "update": {"processed": 3}})

def mark_domain_not_exists(domain_name):
    ensure_token_valid()
    session.put(MARK_NOT_FOUND_URL, json={"filter": {"domain_name": domain_name}, "update": {"processed": 5}})

# === PROXY ===
def get_proxy():
    ensure_token_valid()
    r = session.get(GET_PROXY_URL)
    if r.status_code == 200 and r.json().get("success"):
        return r.json()["data"]
    return None

def release_proxy(proxy_id):
    session.put(f"{UPDATE_PROXY_URL}/{proxy_id}", json={"is_used": False})

# === UTILITIES ===
def format_email_pattern(pattern):
    return pattern.replace('[', '{').replace(']', '}').replace('{l}', '{last}').replace('{f}', '{first_initial}')

def fetch_with_proxy(url, proxy):
    try:
        proxy_str = f"http://{proxy['user']}:{proxy['pass']}@{proxy['host']}:{proxy['port']}"
        headers = {
            "User-Agent": "Mozilla/5.0",
            "Referer": "https://google.com",
            "Accept-Language": "en-US,en;q=0.9"
        }
        r = requests.get(url, headers=headers, proxies={"http": proxy_str, "https": proxy_str}, timeout=10)
        if r.status_code == 403 or 'captcha' in r.text.lower():
            print(f"🚫 Blocked or CAPTCHA: {url}")
            return None
        return r.text if r.status_code == 200 else None
    except Exception as e:
        print(f"❌ Request failed for {url}: {e}")
        return None

# === SEARCH ===

# === PATCHED SEARCH FUNCTION ===
async def search_links(domain: str, site: str, active_page: Page):
    global timeout_failures, proxy, page, context, browser

    def extract_links(html, site):
        soup = BeautifulSoup(html, 'html.parser')
        return list({a['href'] for a in soup.find_all('a', href=True) if site in a['href']})

    queries = [
        f"https://duckduckgo.com/?q=\"@{domain}\"+site%3A{site}&ia=web",
        f"https://www.bing.com/search?q=\"@{domain}\"+site:{site}"
    ]

    for query in queries:
        try:
            print(f"🔍 Trying search engine: {query}")
            await active_page.goto(query, wait_until="load", timeout=15000)
            await active_page.wait_for_timeout(2000)
            html = await active_page.content()
            soup = BeautifulSoup(html, 'html.parser')

            if any(keyword in soup.text.lower() for keyword in ["bots use duckduckgo", "detected unusual traffic", "captcha"]):
                print("🚨 CAPTCHA or anti-bot triggered.")
                counters['timeout_failures']
                counters['timeout_failures'] += 1
                if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                    print("♻️ Rotating IP and restarting browser due to repeated CAPTCHA/timeout...")
                    rotate_ip(proxy)
                    if context: await context.close()
                    if browser: await browser.close()
                    page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                    counters['timeout_failures'] = 0
                continue

            links = extract_links(html, site)
            if links:
                counters['timeout_failures'] = 0
                return links

        except Exception as e:
            print(f"❌ Search engine error: {e}")
            counters['timeout_failures'] += 1
            if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                print("♻️ Rotating IP and restarting browser due to repeated failures...")
                rotate_ip(proxy)
                if context: await context.close()
                if browser: await browser.close()
                page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                counters['timeout_failures'] = 0
            continue

    print("⚠️ All search engines failed or returned no links.")
    return []

# === PARSERS ===
async def extract_email_patterns(table_body, source_link):
    soup = BeautifulSoup(str(table_body), 'html.parser')
    rows = soup.find_all('tr')
    patterns = []
    for row in rows:
        cols = row.find_all('td')
        if len(cols) >= 3:
            patterns.append({
                "format": format_email_pattern(cols[0].get_text(strip=True)),
                "example": cols[1].get_text(strip=True),
                "percentage": cols[2].get_text(strip=True),
                "source_link": source_link
            })
    return patterns

async def extract_company_details_from_rocketreach(html):
    soup = BeautifulSoup(html, 'html.parser')
    company_info = {}

    try:
        summary = soup.select_one(".headline-summary > p")
        company_info['description'] = summary.get_text(strip=True) if summary else None

        def extract_link(ceid):
            tag = soup.select_one(f'[data-ceid="{ceid}"]')
            return tag['href'] if tag and tag.has_attr('href') else None

        company_info['links'] = {
            'linkedin': extract_link('company-linkedin'),
            'twitter': extract_link('company-twitter'),
            'crunchbase': extract_link('company-crunchbase')
        }

        name_tag = soup.select_one('[data-ceid="company_heading-link_Information"]')
        company_info['company_name'] = name_tag.get_text(strip=True) if name_tag else None

        logo_tag = soup.select_one('.col-sm-2.company-logo img')
        if logo_tag and logo_tag.has_attr('src'):
            company_info['logo'] = logo_tag['src']

        rows = soup.select("table tr")
        for row in rows:
            cols = row.find_all('td')
            if len(cols) != 2:
                continue
            label = cols[0].get_text(strip=True).lower()
            value = cols[1].get_text(strip=True)

            if 'website' in label:
                company_info['website'] = cols[1].a['href'] if cols[1].a and cols[1].a.has_attr('href') else value
            elif 'revenue' in label:
                company_info['revenue'] = value
            elif 'employees' in label:
                company_info['employees'] = value.split()[0]
            elif 'founded' in label:
                company_info['founded'] = value
            elif 'address' in label:
                company_info['address'] = value
            elif 'phone' in label:
                company_info['phone'] = value
            elif 'technologies' in label:
                company_info['technologies'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'industry' in label:
                company_info['industry'] = value
            elif 'web rank' in label:
                company_info['web_rank'] = value
            elif 'keywords' in label:
                company_info['keywords'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'competitors' in label:
                company_info['competitors'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'sic' in label:
                company_info['sic'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'naics' in label:
                company_info['naics'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]

        return company_info

    except Exception as e:
        print(f"❌ Failed to extract company details: {e}")
        return {}

async def extract_company_details_from_contactout(html):
    soup = BeautifulSoup(html, 'html.parser')
    company_info = {}

    try:
        logo_tag = soup.select_one('.companyProfile__photo img')
        if logo_tag and logo_tag.has_attr('src'):
            company_info['logo'] = logo_tag['src']

        name_tag = soup.select_one('.companyProfile__title')
        if name_tag:
            company_info['company_name'] = name_tag.get_text(strip=True)

        description_tag = soup.select_one('.about-text')
        if description_tag:
            company_info['description'] = description_tag.get_text(strip=True)

        links = {}
        link_tags = soup.select('a[rel="nofollow noreferrer"]')
        for tag in link_tags:
            href = tag.get('href', '')
            if "linkedin.com" in href:
                links['linkedin'] = href
            elif "twitter.com" in href:
                links['twitter'] = href
            elif "crunchbase.com" in href:
                links['crunchbase'] = href
        if links:
            company_info['links'] = links

        # Updated: Select proper table structure
        rows = soup.select("tr.companyProfile__table-row")
        for row in rows:
            cols = row.find_all("td")
            if len(cols) != 2:
                continue

            # Get label from the span inside the first td
            label_span = cols[0].find("span")
            if not label_span:
                continue
            label = label_span.get_text(strip=True).lower()

            # Get value from the second td
            value_div = cols[1].find("div", class_="companyProfile__contacts-text")
            value = value_div.get_text(strip=True) if value_div else cols[1].get_text(strip=True)

            # Match and assign to company_info
            if 'website' in label:
                link_tag = cols[1].find("a")
                company_info['website'] = link_tag['href'] if link_tag and link_tag.has_attr('href') else value
            elif 'revenue' in label:
                company_info['revenue'] = value
            elif 'employees' in label:
                company_info['employees'] = value
            elif 'founded' in label:
                company_info['founded'] = value
            elif 'location' in label or 'address' in label:
                company_info['address'] = value
            elif 'phone' in label:
                company_info['phone'] = value
            elif 'industry' in label:
                company_info['industry'] = value
            elif 'keywords' in label:
                company_info['keywords'] = [kw.strip() for kw in value.split(",") if kw.strip()]

        return company_info

    except Exception as e:
        print(f"❌ Failed to extract ContactOut company details: {e}")
        return {}

# === SCRAPER ===
async def process_rocketreach(domain, page):
    links = await search_links(domain, 'rocketreach.co', page)
    for link in links:
        if '-email-format_' in link:
            email_html = fetch_with_proxy(link, proxy)
            if not email_html: continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.headline-summary .table-wpr .table tbody')
            patterns = await extract_email_patterns(table, link) if table else []
            profile_url = link.replace('-email-format_', '-profile_')
            profile_html = fetch_with_proxy(profile_url, proxy)
            details = await extract_company_details_from_rocketreach(profile_html) if profile_html else {}
            if patterns:
                update_domain(domain, patterns, details)
                return True
        elif '-profile_' in link:
            profile_html = fetch_with_proxy(link, proxy)
            if not profile_html: continue
            details = await extract_company_details_from_rocketreach(profile_html)
            email_url = link.replace('-profile_', '-email-format_')
            email_html = fetch_with_proxy(email_url, proxy)
            soup = BeautifulSoup(email_html, 'html.parser') if email_html else None
            table = soup.select_one('.headline-summary .table-wpr .table tbody') if soup else None
            patterns = await extract_email_patterns(table, email_url) if table else []
            if patterns:
                update_domain(domain, patterns, details)
                return True
    return False

async def process_contactout(domain, page):
    links = await search_links(domain, 'contactout.com', page)
    for link in links:
        # Case 1: link contains -email-format-
        if '-email-format-' in link and 'contactout.com/company/' in link:
            email_html = fetch_with_proxy(link, proxy)
            if not email_html:
                continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.companyProfile__email-format-table.w-full tbody')
            patterns = await extract_email_patterns(table, link) if table else []

            # Now switch to profile page
            profile_url = link.replace('-email-format-', '')
            profile_html = fetch_with_proxy(profile_url, proxy)
            if not profile_html:
                print(f"❌ Profile page fetch failed or blocked: {profile_url}")
            details = await extract_company_details_from_contactout(profile_html) if profile_html else {}

            if patterns:
                update_domain(domain, patterns, details)
                return True

        # Case 2: link contains -profile-
        elif re.match(r"^https://contactout\.com/company/.+-\d+$", link):
            profile_html = fetch_with_proxy(link, proxy)
            if not profile_html:
                continue
            details = await extract_company_details_from_contactout(profile_html)

            # Now switch to email-format page
            email_format_url = re.sub(r'-(\d+)$', r'-email-format-\1', link)
            email_html = fetch_with_proxy(email_format_url, proxy)
            if not email_html:
                continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.companyProfile__email-format-table.w-full tbody')
            patterns = await extract_email_patterns(table, email_format_url) if table else []

            if patterns:
                update_domain(domain, patterns, details)
                return True

    return False

# === MAIN ===
async def main():
    global proxy

    login()
    proxy_data = get_proxy()
    if not proxy_data:
        print("❌ No proxy available, exiting.")
        return

    proxy = {
        "host": proxy_data["ip"],
        "port": proxy_data["port"],
        "user": proxy_data["user"],
        "pass": proxy_data["password"],
        "protocol": proxy_data["protocol"] == "https",
        "timezone": "America/New_York",
        "api_key": proxy_data["api_key"],
        "api_url": proxy_data["api_url"],
        "_id": proxy_data["_id"]
    }

    if not rotate_ip(proxy):
        print("❌ Bandwidth too low or rotation failed. Exiting.")
        release_proxy(proxy["_id"])
        return

    page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
    if not page:
        release_proxy(proxy["_id"])
        return

    try:
        while True:
            try:
                data = get_next_domain()
                if not data:
                    print("🛑 No domain returned. Ending run.")
                    break

                domain = data['domain_name']
                print(f"\n🔍 Processing domain: {domain}")

                 # Check domain exists before searching
                if not check_domain_exists(domain):
                    print(f"🚫 Skipping nonexistent domain: {domain}")
                    mark_domain_not_exists(domain)
                    continue

                success = await process_rocketreach(domain, page) or await process_contactout(domain, page) 
                if not success:
                    mark_domain_not_found(domain)
                    print(f"⚠️ No email format found for {domain}")

                counters['processed_count'] += 1
                counters['timeout_failures'] = 0  # Reset on success

                if counters['processed_count'] % 50 == 0:
                    print("♻️ Resetting context after 50 domains...")
                    await context.close()

                    if not rotate_ip(proxy):
                        print("❌ Bandwidth too low on context reset. Exiting.")
                        break

                    page, context, _ = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                    if not page:
                        print("❌ Failed to relaunch context. Exiting.")
                        break

            except Exception as inner_error:
                print(f"⚠️ Inner error occurred: {inner_error}")
                counters['timeout_failures'] += 1

                if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                    print("🔁 Rotating IP due to repeated timeouts...")
                    if not rotate_ip(proxy):
                        print("❌ Bandwidth too low during timeout recovery. Exiting.")
                        break
                    counters['timeout_failures'] = 0

                print("🔁 Attempting to recover browser...")

                if 'context' in locals(): await context.close()
                if 'browser' in locals(): await browser.close()

                page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                if not page:
                    print("❌ Failed to recover browser. Exiting...")
                    break

    except Exception as e:
        print(f"💥 Outer Error occurred: {e}")

    finally:
        if 'context' in locals():
            await context.close()
        if 'browser' in locals():
            await browser.close()
        release_proxy(proxy["_id"])
        print("\n✅ Script finished.")

if __name__ == "__main__":
    asyncio.run(main())
