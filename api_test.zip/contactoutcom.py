import requests
from bs4 import BeautifulSoup
import time
import random
import jwt
import asyncio
from playwright.async_api import Page
import chrome_playwrite_proxy  # Your custom Playwright launcher
import re
from playwright.async_api import async_playwright

# === GLOBAL CONFIG ===
API_BASE = "https://app.liscrapox.com"
LOGIN_URL = f"{API_BASE}/api/login"
NEXT_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next"
UPDATE_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next/insertorupdate"
MARK_NOT_FOUND_URL = f"{API_BASE}/api/DomainNames/filter"
GET_PROXY_URL = f"{API_BASE}/api/Proxies/next?is_used=0"
UPDATE_PROXY_URL = f"{API_BASE}/api/Proxies"
NEXT_LINK_URL = f"{API_BASE}/api/linkstoscrap/next"
UPDATE_LINK_URL = f"{API_BASE}/api/linkstoscrap/next/insertorupdate"
MARK_LINK_NOT_FOUND_URL = f"{API_BASE}/api/linkstoscrap/filter"
ADD_LINK_URL = f"{API_BASE}/api/linkstoscrap/"
USE_PROXY =False
REFERERS = [
    "https://www.google.com/",
    "https://www.bing.com/",
    "https://duckduckgo.com/"
]

def random_chrome_user_agent():
    chrome_user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    ]
    return random.choice(chrome_user_agents)

session = requests.Session()
access_token = None
refresh_token = None
proxy = None  # Global proxy instance
page, context, browser = None, None, None  # global browser context
TIMEOUT_THRESHOLD = 3
counters = {
    "timeout_failures": 0,
    "processed_count": 0
}


# === CAPTCHA HANDLER ===
def is_captcha_page(html):
    soup = BeautifulSoup(html, 'html.parser')
    if "Unfortunately, bots use DuckDuckGo too" in soup.text:
        print("🛑 CAPTCHA detected on DuckDuckGo!")
        return True
    return False

# === DOMAIN EXISTENCE CHECK ===
def check_domain_exists(domain):
    try:
        response = requests.head(f"http://{domain}", timeout=5)
        return response.status_code < 400
    except:
        return False
    
# === AUTH ===
def login():
    try:
        global access_token, refresh_token
        response = requests.post(LOGIN_URL, json={"username": "keshav1", "password": "keshav1"})
        if response.status_code == 200:
            data = response.json()
            access_token = data['accessToken']
            refresh_token = data['refreshToken']
            session.headers.update({"Authorization": f"Bearer {access_token}"})
        else:
            print("❌ Login failed")
            exit(1)
    except Exception as e:
        print("❌ Login failed:", e)
        exit(1)

def is_token_expired():
    try:
        decoded = jwt.decode(access_token, options={"verify_signature": False})
        exp_time = decoded.get("exp")
        return not exp_time or time.time() > exp_time - 60
    except:
        return True

def ensure_token_valid():
    if is_token_expired():
        login()

def get_traffic_left(proxy):
    try:
        url = f"https://{proxy['user']}:{proxy['pass']}@{proxy['api_url']}/api/stats"
        headers = {"Authorization": f"Bearer {proxy['api_key']}"}
        res = requests.get(url, headers=headers, timeout=10)
        return res.json().get("traffic_left", 0)
    except Exception as e:
        print("❌ Failed to check bandwidth:", e)
        return 0

def rotate_ip(proxy):
    traffic = get_traffic_left(proxy)
    if traffic < 1 * 1024 * 1024:
        print("🚫 Not enough bandwidth left.")
        return False
    try:
        url = f"https://{proxy['user']}:{proxy['pass']}@{proxy['api_url']}/api/rotate_ip"
        headers = {"Authorization": f"Bearer {proxy['api_key']}"}
        res = requests.get(url, headers=headers, params={"port": proxy["port"]}, timeout=10)
        print("🔁 IP rotated successfully.")
        return res.ok
    except Exception as e:
        print("❌ Failed to rotate IP:", e)
        return False
# === DATA FETCH/UPDATE ===
def get_next_domain():
    ensure_token_valid()
    response = session.get(NEXT_DOMAIN_URL)
    if response.status_code == 200:
        data = response.json()
        return data.get("data")
    return None

def get_next_link():
    ensure_token_valid()
    response = session.get(NEXT_LINK_URL)
    print(NEXT_LINK_URL)
    if response.status_code == 200:
        data = response.json()
        print(data)
        return data.get("data")
    return None


def update_domain(domain_name='', email_patterns=[], company_details=[]):
    ensure_token_valid()
    print(domain_name)

    example_email = email_patterns[0].get('example', '')
    domain_match = re.search(r'@([\w.-]+)', example_email)
    matched_domain = domain_match.group(1) if domain_match else domain_name  # fallback to passed domain

    payload = {
        "filter": {"domain_name": matched_domain},
        "update": {
            "processed": 2,
            "email_format": email_patterns
        }
    }
    print(payload)
    session.put(UPDATE_DOMAIN_URL, json=payload)


def mark_domain_not_found(domain_name):
    ensure_token_valid()
    session.put(MARK_NOT_FOUND_URL, json={"filter": {"domain_name": domain_name}, "update": {"processed": 3}})

def mark_domain_not_exists(domain_name):
    ensure_token_valid()
    session.put(MARK_NOT_FOUND_URL, json={"filter": {"domain_name": domain_name}, "update": {"processed": 5}})

def mark_link_not_found(link):
    ensure_token_valid()
    session.put(MARK_LINK_NOT_FOUND_URL, json={"filter": {"link": link}, "update": {"processed": 3}})


# === PROXY ===
def get_proxy():
    ensure_token_valid()
    r = session.get(GET_PROXY_URL)
    if r.status_code == 200 and r.json().get("success"):
        return r.json()["data"]
    return None

def release_proxy(proxy_id):
    session.put(f"{UPDATE_PROXY_URL}/{proxy_id}", json={"is_used": False})

# === UTILITIES ===
def format_email_pattern(pattern):
    return pattern.replace('[', '{').replace(']', '}').replace('{l}', '{last}').replace('{f}', '{first_initial}')

async def fetch_with_playwright(url, page):
    try:
        await page.goto(url, wait_until='load', timeout=60000)
        await page.wait_for_load_state('networkidle')
        return await page.content()
    except Exception as e:
        print(f"❌ Playwright fetch failed: {e}")
        return None


def fetch_with_proxy(url, proxy):
    try:
        proxy_str = f"http://{proxy['user']}:{proxy['pass']}@{proxy['host']}:{proxy['port']}"
        user_agent = random_chrome_user_agent()
        headers = {
            "User-Agent": user_agent,
            "Referer": random.choice(REFERERS),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Sec-Fetch-Site": "none",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Dest": "document",
            "Sec-Ch-Ua": '"Chromium";v="122", "Not:A-Brand";v="99"',
            "Sec-Ch-Ua-Mobile": "?0",
            "Sec-Ch-Ua-Platform": '"Windows"',
            "Upgrade-Insecure-Requests": "1",
            "Connection": "keep-alive"
        }

        r = requests.get(url, headers=headers, proxies={"http": proxy_str, "https": proxy_str}, timeout=10)
        if r.status_code == 403 or 'captcha' in r.text.lower():
            print(f"🚫 Blocked or CAPTCHA: {url}")
            return None
        counters['processed_count'] += 1
        return r.text if r.status_code == 200 else None
    except Exception as e:
        print(f"❌ Request failed for {url}: {e}")
        return None

# === SEARCH Domain===
async def search_links(domain: str, site: str, active_page: Page):
    global timeout_failures, proxy, page, context, browser,USE_PROXY

    def extract_links(html: str, site: str):
        soup = BeautifulSoup(html, 'html.parser')
        links = set()

        for a in soup.find_all('a', href=True):
            href = a['href']
            if site in href and href.startswith("http"):
                links.add(href)

            # Handle Bing redirect-style links (if present)
            match = re.search(r'/url\?q=(https?://[^&]+)', href)
            if match and site in match.group(1):
                links.add(match.group(1))

        return list(links)

    queries = [
        f'https://ducduckgo.com/?t=h_&q=email"%40{domain}\"+site%3A{site}&ia=web',
        f'https://bing.com/?t=h_&q=email"%40{domain}\"+site%3A{site}&ia=web',
    ]

    for query in queries:
        try:
            print(f"🔍 Trying search engine: {query}")
            await active_page.goto(query, wait_until='domcontentloaded', timeout=15000)
            await active_page.wait_for_load_state('networkidle')
            await detect_captcha_for_url(active_page)

            html = await active_page.content()
            soup = BeautifulSoup(html, 'html.parser')

            if any(keyword in soup.text.lower() for keyword in ["bots use duckduckgo", "detected unusual traffic", "captcha"]):
                print("🚨 CAPTCHA or anti-bot triggered.")
                counters['timeout_failures'] += 1
                if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                    print("♻️ Rotating IP and restarting browser due to repeated CAPTCHA/timeout...")
                    rotate_ip(proxy)
                    if context: await context.close()
                    if browser: await browser.close()
                    await chrome_playwrite_proxy.shutdown_browser(browser=browser, context=context)
                    page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                    if USE_PROXY:
                        try:
                            release_proxy(proxy["_id"])
                        except Exception as e:
                            print(f"⚠️ Failed to release proxy: {e}")
                    counters['timeout_failures'] = 0
                continue

            links = extract_links(html, site)
            print(links)
            if links:
                counters['timeout_failures'] = 0
                return links

        except Exception as e:
            print(f"❌ Search engine error: {e}")
            counters['timeout_failures'] += 1
            if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                print("♻️ Rotating IP and restarting browser due to repeated failures...")
                rotate_ip(proxy)
                if context: await context.close()
                if browser: await browser.close()
                await chrome_playwrite_proxy.shutdown_browser(browser=browser, context=context)
                if USE_PROXY:
                    try:
                        release_proxy(proxy["_id"])
                    except Exception as e:
                        print(f"⚠️ Failed to release proxy: {e}")
                page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy)
                
                counters['timeout_failures'] = 0
            continue

    print("⚠️ All search engines failed or returned no links.")
    return []

# === PARSERS ===
async def extract_email_patterns(table_body, source_link):
    soup = BeautifulSoup(str(table_body), 'html.parser')
    rows = soup.find_all('tr')
    patterns = []
    for row in rows:
        cols = row.find_all('td')
        if len(cols) >= 3:
            patterns.append({
                "format": format_email_pattern(cols[0].get_text(strip=True)),
                "example": cols[1].get_text(strip=True),
                "percentage": cols[2].get_text(strip=True),
                "source_link": source_link
            })
    return patterns

async def extract_company_details_from_rocketreach(html):
    soup = BeautifulSoup(html, 'html.parser')
    company_info = {}

    try:
        summary = soup.select_one(".headline-summary > p")
        company_info['description'] = summary.get_text(strip=True) if summary else None

        def extract_link(ceid):
            tag = soup.select_one(f'[data-ceid="{ceid}"]')
            return tag['href'] if tag and tag.has_attr('href') else None

        company_info['links'] = {
            'linkedin': extract_link('company-linkedin'),
            'twitter': extract_link('company-twitter'),
            'crunchbase': extract_link('company-crunchbase')
        }

        name_tag = soup.select_one('[data-ceid="company_heading-link_Information"]')
        company_info['company_name'] = name_tag.get_text(strip=True) if name_tag else None

        logo_tag = soup.select_one('.col-sm-2.company-logo img')
        if logo_tag and logo_tag.has_attr('src'):
            company_info['logo'] = logo_tag['src']

        rows = soup.select("table tr")
        for row in rows:
            cols = row.find_all('td')
            if len(cols) != 2:
                continue
            label = cols[0].get_text(strip=True).lower()
            value = cols[1].get_text(strip=True)

            if 'website' in label:
                company_info['website'] = cols[1].a['href'] if cols[1].a and cols[1].a.has_attr('href') else value
            elif 'revenue' in label:
                company_info['revenue'] = value
            elif 'employees' in label:
                company_info['employees'] = value.split()[0]
            elif 'founded' in label:
                company_info['founded'] = value
            elif 'address' in label:
                company_info['address'] = value
            elif 'phone' in label:
                company_info['phone'] = value
            elif 'technologies' in label:
                company_info['technologies'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'industry' in label:
                company_info['industry'] = value
            elif 'web rank' in label:
                company_info['web_rank'] = value
            elif 'keywords' in label:
                company_info['keywords'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'competitors' in label:
                company_info['competitors'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'sic' in label:
                company_info['sic'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]
            elif 'naics' in label:
                company_info['naics'] = [a.get_text(strip=True) for a in cols[1].find_all('a')]

        return company_info

    except Exception as e:
        print(f"❌ Failed to extract company details: {e}")
        return {}

async def extract_company_details_from_contactout(html):
    soup = BeautifulSoup(html, 'html.parser')
    company_info = {}

    try:
        logo_tag = soup.select_one('.companyProfile__photo img')
        if logo_tag and logo_tag.has_attr('src'):
            company_info['logo'] = logo_tag['src']

        name_tag = soup.select_one('.companyProfile__title')
        if name_tag:
            company_info['company_name'] = name_tag.get_text(strip=True)

        description_tag = soup.select_one('.about-text')
        if description_tag:
            company_info['description'] = description_tag.get_text(strip=True)

        links = {}
        link_tags = soup.select('a[rel="nofollow noreferrer"]')
        for tag in link_tags:
            href = tag.get('href', '')
            if "linkedin.com" in href:
                links['linkedin'] = href
            elif "twitter.com" in href:
                links['twitter'] = href
            elif "crunchbase.com" in href:
                links['crunchbase'] = href
        if links:
            company_info['links'] = links

        # Updated: Select proper table structure
        rows = soup.select("tr.companyProfile__table-row")
        for row in rows:
            cols = row.find_all("td")
            if len(cols) != 2:
                continue

            # Get label from the span inside the first td
            label_span = cols[0].find("span")
            if not label_span:
                continue
            label = label_span.get_text(strip=True).lower()

            # Get value from the second td
            value_div = cols[1].find("div", class_="companyProfile__contacts-text")
            value = value_div.get_text(strip=True) if value_div else cols[1].get_text(strip=True)

            # Match and assign to company_info
            if 'website' in label:
                link_tag = cols[1].find("a")
                company_info['website'] = link_tag['href'] if link_tag and link_tag.has_attr('href') else value
            elif 'revenue' in label:
                company_info['revenue'] = value
            elif 'employees' in label:
                company_info['employees'] = value
            elif 'founded' in label:
                company_info['founded'] = value
            elif 'location' in label or 'address' in label:
                company_info['address'] = value
            elif 'phone' in label:
                company_info['phone'] = value
            elif 'industry' in label:
                company_info['industry'] = value
            elif 'keywords' in label:
                company_info['keywords'] = [kw.strip() for kw in value.split(",") if kw.strip()]

        return company_info

    except Exception as e:
        print(f"❌ Failed to extract ContactOut company details: {e}")
        return {}

# === SCRAPER ===
async def process_rocketreach(domain, page):
    links = await search_links(domain, 'rocketreach.co', page)
    for link in links:
        if '-email-format_' in link:
            email_html = await  fetch_with_playwright(link, page)
            if not email_html: continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.headline-summary .table-wpr .table tbody')
            patterns = await extract_email_patterns(table, link) if table else []
            profile_url = link.replace('-email-format_', '-profile_')
            profile_html =await  fetch_with_playwright(profile_url, page)
            details = await extract_company_details_from_rocketreach(profile_html) if profile_html else {}
            if patterns:
                update_domain(domain, patterns, details)
                return True
        elif '-profile_' in link:
            profile_html =await  fetch_with_playwright(link, page)
            if not profile_html: continue
            details = await extract_company_details_from_rocketreach(profile_html)
            email_url = link.replace('-profile_', '-email-format_')
            email_html = await  fetch_with_playwright(email_url, page)
            soup = BeautifulSoup(email_html, 'html.parser') if email_html else None
            table = soup.select_one('.headline-summary .table-wpr .table tbody') if soup else None
            patterns = await extract_email_patterns(table, email_url) if table else []
            if patterns:
                print(domain, patterns, details)
                update_domain(domain, patterns, details)
                return True
    return False

async def process_contactout(domain, page):
    links = await search_links(domain, 'contactout.com', page)
    for link in links:
        # Case 1: link contains -email-format-
        if '-email-format-' in link and 'contactout.com/company/' in link:
            email_html =await  fetch_with_playwright(link, page)
            if not email_html:
                continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.companyProfile__email-format-table.w-full tbody')
            patterns = await extract_email_patterns(table, link) if table else []

            # Now switch to profile page
            profile_url = link.replace('-email-format-', '')
            profile_html =await  fetch_with_playwright(profile_url, page)
            if not profile_html:
                print(f"❌ Profile page fetch failed or blocked: {profile_url}")
            details = await extract_company_details_from_contactout(profile_html) if profile_html else {}

            if patterns:
                update_domain(domain, patterns, details)
                return True

        # Case 2: link contains -profile-
        elif re.match(r"^https://contactout\.com/company/.+-\d+$", link):
            profile_html = await  fetch_with_playwright(link, page)
            if not profile_html:
                continue
            details = await extract_company_details_from_contactout(profile_html)

            # Now switch to email-format page
            email_format_url = re.sub(r'-(\d+)$', r'-email-format-\1', link)
            email_html = await  fetch_with_playwright(email_format_url, page)
            if not email_html:
                continue
            soup = BeautifulSoup(email_html, 'html.parser')
            table = soup.select_one('.companyProfile__email-format-table.w-full tbody')
            patterns = await extract_email_patterns(table, email_format_url) if table else []

            if patterns:
                update_domain(domain, patterns, details)
                return True

    return False

async def process_contactout_direct_link_industry(link: str, page: Page):
    ensure_token_valid()
    print(f"➡️ Visiting industry page: {link}")

    try:
        await page.goto(link, wait_until='domcontentloaded', timeout=30000)
        await page.wait_for_load_state('networkidle')
        await detect_captcha_for_url(page)
        await page.wait_for_timeout(2000)

        html = await page.content()
        soup = BeautifulSoup(html, 'html.parser')
        # Extract all company page links directly
        link_tags = soup.select('.directory__list a')
        for a in link_tags:
            href = a.get('href')
            if href:
                full_url = "https://contactout.com" + href
                session.post(ADD_LINK_URL, json={
                    "link": full_url,
                    "type": "companyLinkPageContactOut",
                    "processed": 0
                })
                print(f"   ✅ Found company page: {full_url}")
        if not '?page=' in link :
            # Optional: check for pagination count
            # Get highest page number from all pagination links
            pagination_links = soup.select('nav[aria-label="Pagination Navigation"] a')
            max_page = 1
            for a in pagination_links:
                page_text = a.get_text(strip=True)
                if page_text.isdigit():
                    max_page = max(max_page, int(page_text))

            # Generate pagination URLs if more than one page
            for i in range(2, max_page + 1):
                paginated_url = f"{link}?page={i}"
                session.post(ADD_LINK_URL, json={
                    "link": full_url,
                    "type": "companyLinkPaginationContactOut",
                    "processed": 0
                })
                print(f"   ➕ Queued pagination: {paginated_url}")
                # === Push to API ===
        return True

    except Exception as e:
        print(f"❌ Failed to process link {link}: {e}")
        return False

async def process_contactout_playwrite(email_format_url, page):
    ensure_token_valid()
    print(f"➡️ Visiting company profile page: {email_format_url}")
    try:
        email_html =await  fetch_with_playwright(email_format_url, page)
        if not email_html:
            print(f"⚠️ Failed to fetch email-format page: {email_format_url}")
            return False

        soup = BeautifulSoup(email_html, 'html.parser')
        table = soup.select_one('.companyProfile__email-format-table.w-full tbody')
        patterns = await extract_email_patterns(table, email_format_url) if table else []

        if patterns:
            example_email = patterns[0].get('example', '')
            domain_match = re.search(r'@([\w.-]+)', example_email)
            if domain_match:
                domain = domain_match.group(1)
                update_domain(domain, patterns)
                print(f"✅ Updated domain: {domain}")
                return True
            else:
                print("⚠️ Skipping. No domain found in email example.")
                return False  # No fallback; skip update

        print("⚠️ No patterns found.")
        return False

    except Exception as e:
        print(f"❌ Failed to process link {email_format_url}: {e}")
        return False

async def detect_captcha_for_url(page, wait_time: int = 60):
    await asyncio.sleep(1)  # Let the page fully load dynamic content
    await page.wait_for_timeout( 1000) 
    # CAPTCHA checks
    recaptcha = await page.locator('iframe[src*="recaptcha"]').count()
    hcaptcha = await page.locator('iframe[src*="hcaptcha"]').count()
    text_captcha = await page.locator('input[aria-label*="captcha"], input[name*="captcha"]').count()
    turnstile = await page.locator('iframe[src*="turnstile"]').count()
    cloudflare_check = "checking your browser" in (await page.content()).lower()

    # Try clicking simple reCAPTCHA checkbox if it's present
    if recaptcha:
        print(f"✅ reCAPTCHA detected ({recaptcha} iframe(s))")
        try:
            frame = page.frame_locator('iframe[src*="recaptcha"]').first
            checkbox = frame.locator(".recaptcha-checkbox-border")
            await checkbox.click()
            print("☑️ Clicked reCAPTCHA checkbox. Waiting for it to complete...")
            await asyncio.sleep(wait_time)
            return True
        except Exception as e:
            print(f"⚠️ Failed to click reCAPTCHA checkbox: {e}")

    # Log other types
    captcha_found = False
    if hcaptcha:
        print(f"✅ hCaptcha detected ({hcaptcha} iframe(s))")
        captcha_found = True
    if text_captcha:
        print(f"✅ Text/Image CAPTCHA input field detected ({text_captcha} input(s))")
        captcha_found = True
    if turnstile:
        print(f"✅ Cloudflare Turnstile CAPTCHA detected ({turnstile} iframe(s))")
        captcha_found = True
    if cloudflare_check:
        print("✅ Cloudflare JavaScript challenge detected")
        captcha_found = True

    if captcha_found:
        print(f"⏳ CAPTCHA detected. Waiting {wait_time} seconds...")
        await asyncio.sleep(wait_time)
        await page.wait_for_timeout(wait_time*1000) 
        return True
    else:
        print("❌ No CAPTCHA detected.")
        return False

async def main(USE_PROXY=True, headless=False, exe_path=None):
    global proxy, page, context, browser

    login()

    if USE_PROXY:
        proxy_data = get_proxy()
        if not proxy_data:
            print("❌ No proxy available, exiting.")
            return

        proxy = {
            "host": proxy_data["ip"],
            "port": proxy_data["port"],
            "user": proxy_data["user"],
            "pass": proxy_data["password"],
            "protocol": proxy_data["protocol"] == "https",
            "timezone": "America/New_York",
            "api_key": proxy_data["api_key"],
            "api_url": proxy_data["api_url"],
            "_id": proxy_data["_id"]
        }

        if not rotate_ip(proxy):
            print("❌ Bandwidth too low or rotation failed. Exiting.")
            release_proxy(proxy["_id"])
            return

        page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy, headless, exe_path)

    else:
        page, context, browser = await chrome_playwrite_proxy.run_playwright_without_proxy(headless, exe_path)

    if not page:
        if USE_PROXY:
            release_proxy(proxy["_id"])
        return

    try:
        while True:
            try:
                data = get_next_link()
                if not data:
                    print("🛑 No domain returned. Ending run.")
                    break

                link = data['link']
                linktype = data['type']
                print(f"\n🔍 Processing domain: {link}")

                if linktype == 'searchDomain':
                    if not check_domain_exists(link):
                        print(f"🚫 Skipping nonexistent domain: {link}")
                        mark_domain_not_exists(link)
                        continue

                    success = await process_rocketreach(link, page) or await process_contactout(link, page)
                    if not success:
                        mark_domain_not_found(link)
                        print(f"⚠️ No email format found for {link}")

                elif 'contactout.com/company-directory/industries/' in link:
                    success = await process_contactout_direct_link_industry(link, page)
                    if not success:
                        mark_link_not_found(link)
                        print(f"⚠️ No company links found on industry page: {link}")
                
                elif 'contactout.com/company/'  in link and '-email-format-' not in link:
                    link = re.sub(r'-(\d+)$', r'-email-format-\1', link)
                    success = await process_contactout_playwrite(link, page)
                    if not success:
                        mark_link_not_found(link)
                        print(f"⚠️ No email pattern found for company link: {link}")
                elif 'contactout.com/company/'  in link and '-email-format-' in link:
                    success = await process_contactout_playwrite(link, page)
                    if not success:
                        mark_link_not_found(link)
                        print(f"⚠️ No email pattern found for company link: {link}")

                counters['processed_count'] += 1
                counters['timeout_failures'] = 0

                if counters['processed_count'] % 5 == 0:
                    print("♻️ Closing and restarting browser after 5 domains...")
                    await chrome_playwrite_proxy.shutdown_browser(browser=browser, context=context)
                     # 💡 Explicitly set browser/context/page to None to ensure cleanup
                    context = None
                    browser = None
                    page = None
                    if USE_PROXY:
                        if not rotate_ip(proxy):
                            print("❌ Bandwidth too low on context reset. Exiting.")
                            break
                        page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy, headless, exe_path)
                    else:
                        page, context, browser = await chrome_playwrite_proxy.run_playwright_without_proxy(headless, exe_path)

                    if not page:
                        print("❌ Failed to relaunch browser. Exiting.")
                        break

            except Exception as inner_error:
                print(f"⚠️ Inner error occurred: {inner_error}")
                counters['timeout_failures'] += 1

                if counters['timeout_failures'] >= TIMEOUT_THRESHOLD:
                    print("🔁 Rotating IP due to repeated timeouts...")
                    await chrome_playwrite_proxy.shutdown_browser(browser=browser, context=context)
                    context = None
                    browser = None
                    page = None
                    if USE_PROXY:
                        if not rotate_ip(proxy):
                            print("❌ Bandwidth too low during timeout recovery. Exiting.")
                            break

                        page, context, browser = await chrome_playwrite_proxy.run_playwright_with_proxy(proxy, headless, exe_path)
                    else:
                        page, context, browser = await chrome_playwrite_proxy.run_playwright_without_proxy(headless, exe_path)

                    if not page:
                        print("❌ Failed to recover browser. Exiting...")
                        break

                    counters['timeout_failures'] = 0

    except Exception as e:
        print(f"💥 Outer Error occurred: {e}")

    finally:
        try:
            await chrome_playwrite_proxy.shutdown_browser(browser=browser, context=context)
        except Exception as e:
            print(f"⚠️ Shutdown failed: {e}")
        browser, context, page = None, None, None
        if USE_PROXY:
            try:
                release_proxy(proxy["_id"])
            except Exception as e:
                print(f"⚠️ Failed to release proxy: {e}")
        print("\n✅ Script finished.")

if __name__ == "__main__":
    asyncio.run(main(USE_PROXY=True, headless=True, exe_path="C:/Program Files/Google/Chrome/Application/chrome.exe"))
