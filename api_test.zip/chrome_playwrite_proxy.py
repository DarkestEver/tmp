# chrome_playwrite_proxy.py
import asyncio
import random
from playwright.async_api import async_playwright
from RandomUserAgent import random_chrome_user_agent
from playwright_stealth import stealth_async
import psutil

playwright_instance = None

SCREEN_SIZES = [
    (1366, 768), (1920, 1080), (1536, 864), (1440, 900), (1280, 720)
]

FAKE_REFERRERS = [
    "https://www.google.com/search?q=your+brand",
    "https://www.bing.com/search?q=business+tools",
    "https://duckduckgo.com/?q=lead+generation+platform"
]

WEBGL_DATA = [
    {"vendor": "NVIDIA Corporation", "renderer": f"NVIDIA GeForce RTX {random.randint(3060, 4090)}"},
    {"vendor": "Intel Corporation", "renderer": f"Intel UHD Graphics {random.randint(600, 800)}"}
]

async def launch_browser(proxy=None, headless=False, exe_path=None):
    global playwright_instance
    if not playwright_instance:
        playwright_instance = await async_playwright().start()

    screen_width, screen_height = random.choice(SCREEN_SIZES)
    fake_user_agent = random.choice(random_chrome_user_agent())

    proxy_config = None
    if proxy:
        protocol = "https" if proxy.get("protocol", False) else "http"
        proxy_config = {
            "server": f"{protocol}://{proxy['host']}:{proxy['port']}",
        }
        if "user" in proxy and "pass" in proxy:
            proxy_config["username"] = proxy["user"]
            proxy_config["password"] = proxy["pass"]

    try:
        browser = await playwright_instance.chromium.launch(
            headless=headless,
            executable_path=exe_path,
            proxy=proxy_config,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-site-isolation-trials",
                "--disable-web-security",
                "--disable-features=IsolateOrigins,site-per-process",
                "--use-gl=desktop",
                "--enable-webgl",
                "--ignore-certificate-errors",
                "--allow-insecure-localhost"
            ]
        )
        context = await browser.new_context(user_agent=fake_user_agent, viewport={"width": screen_width, "height": screen_height})
        page = await context.new_page()
        await stealth_async(page)
        return page, context, browser
    except Exception as e:
        print(f"❌ Launch failed: {e}")
        return None, None, None

async def run_playwright_with_proxy(proxy, headless=False, exe_path=None):
    global playwright_instance
    playwright_instance = None
    return await launch_browser(proxy=proxy, headless=headless, exe_path=exe_path)

async def run_playwright_without_proxy(headless=False, exe_path=None):
    global playwright_instance
    playwright_instance = None
    return await launch_browser(proxy=None, headless=headless, exe_path=exe_path)

async def shutdown_browser(browser=None, context=None):
    global playwright_instance
    try:
        if context and hasattr(context, "is_closed") and not context.is_closed():
            await context.close()
            print("🧹 Context closed.")
    except Exception as e:
        print(f"⚠️ Error closing context: {e}")

    try:
        if browser and hasattr(browser, "is_connected") and browser.is_connected():
            await browser.close()
            print("🧹 Browser closed.")
    except Exception as e:
        print(f"⚠️ Error closing browser: {e}")

    try:
        if playwright_instance:
            await playwright_instance.stop()
            print("🧹 Playwright stopped.")
    except Exception as e:
        print(f"⚠️ Error stopping playwright: {e}")
    
    