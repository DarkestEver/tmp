import requests
from selenium import webdriver
from selenium.webdriver.common.by import By
from bs4 import BeautifulSoup
import time
import random
import jwt

# API URLs
API_BASE = "http://localhost:5073"
LOGIN_URL = f"{API_BASE}/api/login"
NEXT_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next"
UPDATE_DOMAIN_URL = f"{API_BASE}/api/DomainNames/next/insertorupdate"
MARK_NOT_FOUND_URL = f"{API_BASE}/api/DomainNames/filter"

# Auth session
session = requests.Session()
access_token = None
refresh_token = None


def login():
    global access_token, refresh_token
    print("🔐 Logging in...")
    response = requests.post(LOGIN_URL, json={"username": "keshav", "password": "keshav"})
    if response.status_code == 200:
        data = response.json()
        access_token = data['accessToken']
        refresh_token = data['refreshToken']
        session.headers.update({"Authorization": f"Bearer {access_token}"})
        print("✅ Logged in successfully")
    else:
        print("❌ Login failed")
        exit(1)


def is_token_expired():
    try:
        decoded = jwt.decode(access_token, options={"verify_signature": False})
        exp_time = decoded.get("exp")
        if not exp_time:
            return True
        return time.time() > exp_time - 60
    except Exception as e:
        print("⚠️ Failed to decode token:", e)
        return True


def ensure_token_valid():
    if is_token_expired():
        print("🔁 Token expired or near expiry. Refreshing...")
        login()


def get_next_domain():
    ensure_token_valid()
    response = session.get(NEXT_DOMAIN_URL)
    if response.status_code == 200:
        data = response.json()
        if data.get("success") and "data" in data:
            return data['data']
        else:
            print(f"🚫 {data.get('error', 'No more domains to process.')}")
    else:
        print(f"❌ Error fetching domain: {response.status_code} - {response.text}")
    return None


def update_domain(domain_name, email_patterns):
    ensure_token_valid()
    payload = {
        "filter": {"domain_name": domain_name},
        "update": {
            "processed": 2,
            "email_format": email_patterns
        }
    }
    response = session.put(UPDATE_DOMAIN_URL, json=payload)
    print("📡 Update status:", response.status_code, response.text)


def mark_domain_not_found(domain_name):
    ensure_token_valid()
    payload = {
        "filter": {"domain_name": domain_name},
        "update": {"processed": 3}
    }
    response = session.put(MARK_NOT_FOUND_URL, json=payload)
    print("⚠️ Marked as not found:", response.status_code, response.text)


# Selenium setup
options = webdriver.ChromeOptions()
# options.add_argument('--headless')
options.add_argument('--disable-blink-features=AutomationControlled')
options.add_argument('--start-maximized')
driver = webdriver.Chrome(options=options)


def search_links(domain, site):
    engines = [
        f"https://duckduckgo.com/?q=\"@{domain}\"+site%3A{site}&ia=web",
        f"https://www.bing.com/search?q=\"@{domain}\"+site:{site}"
    ]
    selected_engine = random.choice(engines)
    driver.get(selected_engine)
    time.sleep(3)
    soup = BeautifulSoup(driver.page_source, 'html.parser')

    if "detected unusual traffic" in soup.text.lower() or "captcha" in soup.text.lower():
        print("🚨 CAPTCHA or Rate Limiting detected! Exiting run.")
        driver.quit()
        exit(1)

    return list({a['href'] for a in soup.find_all('a', href=True) if site in a['href']})


def format_email_pattern(pattern):
    return pattern.replace('[', '{').replace(']', '}').replace('{l}', '{last}').replace('{f}', '{first_initial}')


def extract_domain_from_email(email):
    return email.split('@')[-1].strip().lower() if '@' in email else ''


def process_rocketreach(domain):
    links = search_links(domain, 'rocketreach.co')
    filtered_links = [link for link in links if "-email-format_" in link]
    for link in filtered_links:
        driver.get(link)
        time.sleep(3)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        table_body = soup.select_one('.headline-summary .table-wpr .table tbody')
        if table_body:
            return parse_and_submit(table_body, domain, link)
    return False


def process_contactout(domain):
    links = search_links(domain, 'contactout.com')
    for link in set(links):
        if "contactout.com/company/" not in link:
            continue
        if link.endswith('/'):
            link = link[:-1]
        split_pos = link.rfind('-')
        if split_pos == -1:
            continue
        email_format_url = link[:split_pos] + "-email-format-" + link[split_pos+1:]
        driver.get(email_format_url)
        time.sleep(3)
        soup = BeautifulSoup(driver.page_source, 'html.parser')
        table_body = soup.select_one('.companyProfile__email-format-table.w-full tbody')
        if table_body:
            return parse_and_submit(table_body, domain, email_format_url)
    return False


def parse_and_submit(table_body, domain, source_link):
    rows = table_body.find_all('tr')
    email_patterns = []
    for row in rows:
        cols = row.find_all('td')
        if len(cols) >= 3:
            raw_format = cols[0].get_text(strip=True)
            formatted = format_email_pattern(raw_format)
            example = cols[1].get_text(strip=True)
            percentage = cols[2].get_text(strip=True)
            email_patterns.append({
                "format": formatted,
                "example": example,
                "percentage": percentage,
                "source_link": source_link
            })

    if email_patterns:
        update_domain(domain, email_patterns)
        print(f"✅ Processed and updated domain: {domain}")
        return True
    return False


# 🔐 Authenticate
login()

# 🔄 Main loop
while True:
    data = get_next_domain()
    if not data:
        print("🛑 No domain returned. Ending run.")
        break

    domain = data['domain_name']
    print(f"\n🔍 Processing domain: {domain}")
    success = process_rocketreach(domain) or process_contactout(domain)
    if not success:
        mark_domain_not_found(domain)
        print(f"⚠️ No email format found for {domain}")

# ✅ Cleanup
driver.quit()
print("\n✅ Script finished.")
