from fastapi import FastAPI
import asyncio
import contactoutcom as contactout

app = FastAPI()
task = None  # Track running task

@app.post("/start")
async def start_scraper():
    global task
    if task and not task.done():
        return {"status": "already running"}
    exe_path = "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"
    task = asyncio.create_task(contactout.main(USE_PROXY=True, headless=False, exe_path=exe_path))
    return {"status": "started"}

@app.post("/stop")
async def stop_scraper():
    global task
    if task and not task.done():
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            return {"status": "cancelled"}
    return {"status": "not running"}
